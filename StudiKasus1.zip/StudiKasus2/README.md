Studi Kasus 2 — Streaming Data Sensor IoT Hemat Memori
1. Deskripsi

Program ini menyimulasikan stasiun pemantau cuaca yang menghasilkan data suhu sensor secara bertahap. Data tidak dimasukkan seluruhnya ke dalam list besar. Setiap nilai suhu dihasilkan, dibaca, dikategorikan, lalu ditampilkan satu per satu.

2. Ketentuan kategori suhu

a. Dingin:** suhu di bawah 20°C.
b. Normal:** suhu 20°C sampai dengan 30°C.
c. Panas:** suhu di atas 30°C.

Program menampilkan 10 pembacaan berturut-turut, dengan simulasi suhu mulai dari 15°C dan kenaikan 2,5°C.

3. Konsep Python yang digunakan

Generator Function dan `yield`

Fungsi `sensor_suhu()` menggunakan `yield` untuk menghasilkan satu nilai suhu setiap kali data diminta. Berbeda dengan membuat list berisi semua suhu sekaligus, generator menghasilkan nilai secara bertahap.

Iterator Pattern dan `next()`

Objek generator diubah menjadi iterator dengan `iter()`. Fungsi `next(data_sensor)` mengambil satu nilai suhu berikutnya. Ketika data sudah habis, Python memberi `StopIteration`, yang ditangani dengan `try-except`.

Efisiensi memori

Program tidak membuat list besar untuk menampung seluruh hasil pembacaan. Nilai suhu diproses satu per satu, sehingga sesuai dengan konsep streaming dan lebih hemat memori untuk aliran data yang besar.

4. Cara menjalankan di Visual Studio Code

1. Ekstrak file ZIP ke folder yang diinginkan.
2. Buka Visual Studio Code.
3. Pilih **File → Open Folder**, lalu buka folder `case-02-streaming-sensor-iot`.
4. Pastikan Python sudah terpasang.
5. Buka file `main.py`.
6. Buka terminal melalui **Terminal → New Terminal**.
7. Jalankan perintah:

   ```bash
   python main.py
   ```

   Jika perintah tersebut tidak berjalan di Windows, coba:

   ```bash
   py main.py
   ```

8. Ambil screenshot output terminal dan simpan sebagai `output.png` di folder kasus untuk bukti eksekusi.

5. Contoh hasil output

```text
====================================================
 SIMULASI STREAMING DATA SENSOR SUHU IoT
====================================================
Pembacaan   Suhu           Status
----------------------------------------------------
1            15.0 °C        Dingin
2            17.5 °C        Dingin
3            20.0 °C        Normal
4            22.5 °C        Normal
5            25.0 °C        Normal
6            27.5 °C        Normal
7            30.0 °C        Normal
8            32.5 °C        Panas
9            35.0 °C        Panas
10           37.5 °C        Panas
----------------------------------------------------
Total pembacaan yang ditampilkan: 10
Data diproses satu per satu menggunakan generator.
====================================================
```

6. Kesimpulan

Program memenuhi kebutuhan simulasi pembacaan data sensor IoT secara bertahap. Generator dengan `yield`, iterator, dan `next()` memungkinkan setiap suhu diproduksi dan diproses ketika diperlukan tanpa menyimpan seluruh data pembacaan ke dalam list besar.
