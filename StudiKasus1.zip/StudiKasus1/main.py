data_mahasiswa = [
    {"nama": "Aisyah", "nim": "230101", "tugas": 85, "uts": 80, "uas": 88},
    {"nama": "Budi", "nim": "230102", "tugas": 70, "uts": 65, "uas": 75},
    {"nama": "Cantika", "nim": "230103", "tugas": 90, "uts": 85, "uas": 92},
    {"nama": "Dimas", "nim": "230104", "tugas": 80, "uts": 82, "uas": 85},
    {"nama": "Eka", "nim": "230105", "tugas": 75, "uts": 78, "uas": 80}
]

mahasiswa_analisis = [
    {
        **m,
        "nilai_akhir": round(
            m["tugas"] * 0.30 +
            m["uts"] * 0.30 +
            m["uas"] * 0.40,
            2
        )
    }
    for m in data_mahasiswa
]

mahasiswa_berprestasi = list(
    filter(
        lambda m: m["nilai_akhir"] > 80,
        mahasiswa_analisis
    )
)

ranking = sorted(
    mahasiswa_analisis,
    key=lambda m: m["nilai_akhir"],
    reverse=True
)

print("=" * 55)
print("          ANALISIS NILAI MAHASISWA")
print("=" * 55)

print("\n1. DAFTAR NILAI AKHIR")
for m in mahasiswa_analisis:
    print(
        f"Nama: {m['nama']:<10} | "
        f"NIM: {m['nim']} | "
        f"Nilai Akhir: {m['nilai_akhir']:.2f}"
    )

print("\n2. MAHASISWA BERPRESTASI (NILAI > 80)")
for m in mahasiswa_berprestasi:
    print(
        f"Nama: {m['nama']} | "
        f"Nilai Akhir: {m['nilai_akhir']:.2f}"
    )

print("\n3. RANKING MAHASISWA")
for peringkat, m in enumerate(ranking, start=1):
    print(
        f"Peringkat {peringkat}: {m['nama']} | "
        f"NIM: {m['nim']} | "
        f"Nilai Akhir: {m['nilai_akhir']:.2f}"
    )

mahasiswa_terbaik = ranking[0]

print("\n4. MAHASISWA TERBAIK")
print(f"Nama       : {mahasiswa_terbaik['nama']}")
print(f"NIM        : {mahasiswa_terbaik['nim']}")
print(f"Nilai Tugas: {mahasiswa_terbaik['tugas']}")
print(f"Nilai UTS  : {mahasiswa_terbaik['uts']}")
print(f"Nilai UAS  : {mahasiswa_terbaik['uas']}")
print(f"Nilai Akhir: {mahasiswa_terbaik['nilai_akhir']:.2f}")

print("=" * 55)
