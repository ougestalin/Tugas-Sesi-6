Studi Kasus 1 Analisis Nilai Mahasiswa

Deskripsi
Program ini digunakan untuk menganalisis nilai mahasiswa berdasarkan tiga komponen, yaitu tugas, UTS, dan UAS. Program menghitung nilai akhir, menampilkan mahasiswa berprestasi dengan nilai akhir di atas 80, mengurutkan seluruh mahasiswa berdasarkan nilai tertinggi, dan menampilkan mahasiswa terbaik beserta detail nilainya.

Bobot Penilaian
1. Tugas : 30%
2. UTS   : 30%
3. UAS   : 40%

Rumus nilai akhir:

`Nilai Akhir = (Tugas × 0.30) + (UTS × 0.30) + (UAS × 0.40)`

Konsep Python yang Digunakan

1. List Comprehension
List comprehension digunakan untuk memproses setiap data mahasiswa dan membuat data baru yang berisi nilai akhir. Data awal tetap dipertahankan.

2. Lambda Function
Lambda adalah fungsi singkat tanpa nama. Dalam program ini, lambda digunakan untuk menentukan kondisi filter dan kunci pengurutan berdasarkan nilai akhir.

3. Filtering
Fungsi `filter()` digunakan untuk memilih mahasiswa yang nilai akhirnya lebih dari 80. Mahasiswa dengan nilai tepat 80 tidak termasuk karena syaratnya adalah di atas 80.

4. Sorting
Fungsi `sorted()` mengurutkan seluruh mahasiswa berdasarkan nilai akhir. Parameter `reverse=True` membuat urutan dimulai dari nilai tertinggi hingga terendah.

5. Mahasiswa Terbaik
Setelah data diurutkan, `ranking[0]` mengambil mahasiswa yang berada di peringkat pertama. Program lalu menampilkan nama, NIM, nilai tugas, UTS, UAS, dan nilai akhirnya.

Cara Menjalankan di VS Code
1. Pastikan Python sudah terpasang.
2. Buka folder proyek ini di Visual Studio Code.
3. Buka file `main.py`.
4. Buka terminal VS Code melalui menu **Terminal → New Terminal**.
5. Jalankan perintah berikut:

   ```bash
   python main.py
   ```

   Jika perintah tersebut tidak bekerja, coba:

   ```bash
   python3 main.py
   ```

6. Periksa hasil perhitungan, daftar mahasiswa berprestasi, ranking, dan mahasiswa terbaik yang muncul di terminal.


Berdasarkan data, ranking dari nilai tertinggi adalah:
1. Cantika  : 89.30
2. Aisyah   : 84.70
3. Dimas    : 82.90
4. Eka      : 77.70
5. Budi     : 70.50

Mahasiswa berprestasi adalah mahasiswa yang nilai akhirnya lebih dari 80: Cantika, Aisyah, dan Dimas. Mahasiswa terbaik adalah Cantika dengan NIM `230103`.

Bukti Eksekusi
Setelah program benar-benar dijalankan, ambil screenshot output terminal dan simpan dengan nama `output.png` di folder ini.
